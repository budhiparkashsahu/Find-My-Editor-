# Find My Editor

A video editing marketplace where creators upload raw footage and editors submit their edited versions. Creators can then review the edits and hire their favourite editor.

## Architecture

- **Frontend**: React + TypeScript + Vite + Wouter (routing) + TanStack Query + Shadcn UI + Tailwind CSS
- **Backend**: Express.js + TypeScript
- **File uploads**: Multer (disk storage, saved to `public/uploads/`)
- **Storage**: In-memory (MemStorage) for all data

## Pages

| Route | Description |
|-------|-------------|
| `/` | Landing page — explains the platform and CTAs |
| `/upload` | Creator page — drag-and-drop raw video upload with title, category, description |
| `/browse` | Editor page — searchable/filterable grid of available raw footage |
| `/video/:id` | Video detail — view original footage, see all submitted edits, hire an editor |
| `/my-videos` | Creator dashboard — email-based lookup to see your uploads and received edits |

## User Flows

**Creator:**
1. Goes to `/upload`, picks a video file, fills in title/description/email, submits
2. Visits `/my-videos`, enters their email to see all uploads
3. Clicks into a video to see submitted edits and hit "Hire This Editor"

**Editor:**
1. Goes to `/browse`, finds a project they like
2. Downloads the raw footage to edit locally
3. Returns to the video page, clicks "Submit My Edit", uploads their edited version + bio

## Color Theme

- Primary: purple `262 83% 58%` (light mode) / `263 70% 65%` (dark mode)
- Background: light blue-gray / deep navy

## Key Files

- `shared/schema.ts` — TypeScript types for Video, EditedVideo, HireRequest
- `server/storage.ts` — In-memory CRUD (IStorage interface + MemStorage)
- `server/routes.ts` — REST API with multer file upload middleware
- `server/index.ts` — Express setup, serves `/uploads` as static
- `client/src/App.tsx` — Routes
- `client/src/components/layout.tsx` — Sidebar navigation
- `client/src/pages/` — All page components
- `public/uploads/` — Uploaded video files

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/videos` | List all uploaded videos |
| POST | `/api/videos` | Upload a new raw video (multipart) |
| GET | `/api/videos/:id` | Get a single video |
| GET | `/api/my-videos?email=...` | Get videos by uploader email |
| GET | `/api/videos/:id/edits` | List edited versions of a video |
| POST | `/api/videos/:id/edits` | Submit an edited version (multipart) |
| POST | `/api/hire` | Send a hire request to an editor |
