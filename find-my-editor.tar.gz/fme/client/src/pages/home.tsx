import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Upload, Search, UserCheck, ArrowRight, Play, Scissors, Star, Zap, Clock } from "lucide-react";

const steps = [
  {
    icon: Upload,
    step: "01",
    title: "Upload Your Raw Video",
    description: "Post your unedited footage with a brief description of the style and feel you're going for. Anyone can view it for free.",
    color: "bg-violet-50 dark:bg-violet-950/30 text-violet-600 dark:text-violet-400",
    cta: { label: "Upload Now", href: "/upload" },
  },
  {
    icon: Scissors,
    step: "02",
    title: "Editors Pick It Up",
    description: "Talented editors browse available projects, download a video they love, and edit it to showcase their skills.",
    color: "bg-amber-50 dark:bg-amber-950/30 text-amber-600 dark:text-amber-400",
    cta: { label: "Browse Videos", href: "/browse" },
  },
  {
    icon: UserCheck,
    step: "03",
    title: "Hire the Best Fit",
    description: "Review all submitted edits side-by-side. Pick your favorite, send a hire request, and start working together.",
    color: "bg-green-50 dark:bg-green-950/30 text-green-600 dark:text-green-400",
    cta: null,
  },
];

const features = [
  { icon: Zap, label: "Instant Access", desc: "No sign-up needed to upload or submit edits" },
  { icon: Star, label: "Multiple Edits", desc: "Receive several edited versions of your footage" },
  { icon: Clock, label: "Fast Turnaround", desc: "Editors are motivated to showcase their best work" },
  { icon: Play, label: "Free to Browse", desc: "All editors can access raw footage at no cost" },
];

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero */}
      <section className="relative px-6 pt-16 pb-20 md:pt-24 md:pb-28 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/8 via-transparent to-violet-500/5 pointer-events-none" />
        <div className="max-w-3xl mx-auto text-center relative">
          <Badge variant="secondary" className="mb-5 px-3 py-1 text-xs font-medium" data-testid="badge-hero">
            🎬 Free Video Editing Marketplace
          </Badge>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground leading-tight tracking-tight mb-5" data-testid="text-hero-heading">
            Find the perfect editor{" "}
            <span className="text-primary">for your video</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-xl mx-auto mb-8 leading-relaxed" data-testid="text-hero-description">
            Upload your raw footage. Talented editors will cut, color, and polish it — then you pick your favorite and hire them.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
            <Link href="/upload">
              <Button size="lg" className="gap-2 w-full sm:w-auto shadow-md" data-testid="button-upload-hero">
                <Upload className="w-4 h-4" /> Upload a Video
              </Button>
            </Link>
            <Link href="/browse">
              <Button variant="outline" size="lg" className="w-full sm:w-auto gap-2" data-testid="button-browse-hero">
                <Scissors className="w-4 h-4" /> I'm an Editor
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="px-6 pb-20 bg-muted/30">
        <div className="max-w-4xl mx-auto pt-16">
          <div className="text-center mb-12">
            <Badge variant="outline" className="mb-3 text-xs">How it works</Badge>
            <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-3">Three simple steps</h2>
            <p className="text-muted-foreground max-w-md mx-auto text-sm">From raw footage to a polished edit, the process is straightforward.</p>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {steps.map(({ icon: Icon, step, title, description, color, cta }) => (
              <Card key={step} className="border border-border bg-card relative overflow-hidden" data-testid={`card-step-${step}`}>
                <div className="absolute top-4 right-4 text-4xl font-black text-border/60 select-none">{step}</div>
                <CardContent className="p-6 pt-8">
                  <div className={`w-11 h-11 rounded-xl flex items-center justify-center mb-4 ${color}`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <h3 className="font-semibold text-foreground mb-2">{title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed mb-4">{description}</p>
                  {cta && (
                    <Link href={cta.href}>
                      <Button variant="ghost" size="sm" className="gap-1.5 px-0 text-primary hover:bg-transparent hover:text-primary/80">
                        {cta.label} <ArrowRight className="w-3.5 h-3.5" />
                      </Button>
                    </Link>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="px-6 py-20">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-10">
            <h2 className="text-2xl font-bold text-foreground mb-2">Why creators love it</h2>
            <p className="text-sm text-muted-foreground">No subscriptions, no gatekeeping — just great editing.</p>
          </div>
          <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-4">
            {features.map(({ icon: Icon, label, desc }) => (
              <div key={label} className="rounded-xl border border-border bg-card p-5 text-center" data-testid={`card-feature-${label.toLowerCase().replace(/\s+/g, "-")}`}>
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center mx-auto mb-3">
                  <Icon className="w-5 h-5 text-primary" />
                </div>
                <p className="font-semibold text-sm text-foreground mb-1">{label}</p>
                <p className="text-xs text-muted-foreground leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA strip */}
      <section className="px-6 pb-20">
        <div className="max-w-3xl mx-auto">
          <div className="rounded-2xl bg-primary p-10 flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <h2 className="text-xl font-bold text-primary-foreground mb-1">Ready to get your video edited?</h2>
              <p className="text-primary-foreground/80 text-sm">Upload your footage and let talented editors do the rest.</p>
            </div>
            <div className="flex gap-3 flex-shrink-0">
              <Link href="/upload">
                <Button variant="secondary" className="gap-2 shadow" data-testid="button-cta-upload">
                  <Upload className="w-4 h-4" /> Upload Video
                </Button>
              </Link>
              <Link href="/browse">
                <Button variant="outline" className="gap-2 bg-transparent border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10" data-testid="button-cta-browse">
                  Browse <ArrowRight className="w-4 h-4" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
