import { useState, useRef } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Upload, Film, CheckCircle2, ArrowRight, X, FileVideo } from "lucide-react";
import { Link } from "wouter";

const uploadSchema = z.object({
  title: z.string().min(3, "Title must be at least 3 characters"),
  description: z.string().min(10, "Please describe what the video is about (min 10 chars)"),
  category: z.string().min(1, "Please select a category"),
  uploaderName: z.string().min(2, "Name must be at least 2 characters"),
  uploaderEmail: z.string().email("Enter a valid email address"),
});

type UploadValues = z.infer<typeof uploadSchema>;

const categories = ["YouTube / Vlog", "Wedding", "Short Film", "Travel", "Corporate", "Music Video", "Sports", "Documentary", "Other"];

export default function UploadPage() {
  const { toast } = useToast();
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const [submittedId, setSubmittedId] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const form = useForm<UploadValues>({
    resolver: zodResolver(uploadSchema),
    defaultValues: { title: "", description: "", category: "", uploaderName: "", uploaderEmail: "" },
  });

  function handleFile(file: File) {
    if (!file.type.startsWith("video/")) {
      toast({ title: "Invalid file", description: "Please select a video file.", variant: "destructive" });
      return;
    }
    setVideoFile(file);
  }

  async function onSubmit(data: UploadValues) {
    if (!videoFile) {
      toast({ title: "No video selected", description: "Please choose a video file to upload.", variant: "destructive" });
      return;
    }
    setIsUploading(true);
    try {
      const fd = new FormData();
      Object.entries(data).forEach(([k, v]) => fd.append(k, v));
      fd.append("video", videoFile);
      const res = await fetch("/api/videos", { method: "POST", body: fd });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || "Upload failed");
      }
      const video = await res.json();
      setSubmittedId(video.id);
      toast({ title: "Video uploaded!", description: "Editors can now find and edit your footage." });
    } catch (e: any) {
      toast({ title: "Upload failed", description: e.message, variant: "destructive" });
    } finally {
      setIsUploading(false);
    }
  }

  if (submittedId) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center px-6">
        <div className="max-w-md w-full text-center" data-testid="status-upload-success">
          <div className="w-16 h-16 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center mx-auto mb-5">
            <CheckCircle2 className="w-8 h-8 text-green-600 dark:text-green-400" />
          </div>
          <h2 className="text-2xl font-bold text-foreground mb-2">Video uploaded!</h2>
          <p className="text-muted-foreground text-sm mb-6">Your footage is now live. Editors will be able to pick it up, cut it, and submit their edits for you to review.</p>
          <div className="flex gap-3 justify-center flex-wrap">
            <Link href={`/video/${submittedId}`}>
              <Button className="gap-2" data-testid="button-view-video">
                View Video Page <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
            <Button variant="outline" onClick={() => { setSubmittedId(null); form.reset(); setVideoFile(null); }} data-testid="button-upload-another">
              Upload Another
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <section className="px-6 pt-16 pb-10 md:pt-20 bg-gradient-to-b from-muted/40 to-transparent">
        <div className="max-w-2xl mx-auto text-center">
          <Badge variant="secondary" className="mb-4 text-xs px-3 py-1">For Creators</Badge>
          <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-3 leading-tight" data-testid="text-upload-heading">
            Upload your raw footage
          </h1>
          <p className="text-muted-foreground text-sm leading-relaxed">
            Share your unedited video and let skilled editors show you what they can do with it. Review their work, then hire your favourite.
          </p>
        </div>
      </section>

      <section className="px-6 pb-20">
        <div className="max-w-2xl mx-auto">
          <Card className="border border-border bg-card">
            <CardContent className="p-6 md:p-8 space-y-6">

              {/* Drop Zone */}
              <div
                onDragOver={e => { e.preventDefault(); setDragOver(true); }}
                onDragLeave={() => setDragOver(false)}
                onDrop={e => { e.preventDefault(); setDragOver(false); const f = e.dataTransfer.files[0]; if (f) handleFile(f); }}
                onClick={() => fileRef.current?.click()}
                className={`rounded-xl border-2 border-dashed transition-colors cursor-pointer flex flex-col items-center justify-center gap-3 py-10 px-6 text-center
                  ${dragOver ? "border-primary bg-primary/5" : "border-border hover:border-primary/50 hover:bg-muted/30"}`}
                data-testid="dropzone-video"
              >
                <input ref={fileRef} type="file" accept="video/*" className="hidden" onChange={e => { const f = e.target.files?.[0]; if (f) handleFile(f); }} />
                {videoFile ? (
                  <>
                    <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                      <FileVideo className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <p className="font-semibold text-foreground text-sm">{videoFile.name}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">{(videoFile.size / 1024 / 1024).toFixed(1)} MB</p>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="gap-1.5 text-destructive hover:text-destructive"
                      onClick={e => { e.stopPropagation(); setVideoFile(null); }}
                      data-testid="button-remove-video"
                    >
                      <X className="w-3.5 h-3.5" /> Remove
                    </Button>
                  </>
                ) : (
                  <>
                    <div className="w-12 h-12 rounded-xl bg-muted flex items-center justify-center">
                      <Film className="w-6 h-6 text-muted-foreground" />
                    </div>
                    <div>
                      <p className="font-semibold text-foreground text-sm">Drop your video here</p>
                      <p className="text-xs text-muted-foreground mt-1">or click to browse · MP4, MOV, WebM up to 500 MB</p>
                    </div>
                  </>
                )}
              </div>

              {/* Form */}
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
                  <FormField control={form.control} name="title" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Video Title</FormLabel>
                      <FormControl><Input placeholder="e.g. My Europe Travel Vlog" data-testid="input-title" {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />

                  <FormField control={form.control} name="category" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Category</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-category">
                            <SelectValue placeholder="Select a category" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {categories.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )} />

                  <FormField control={form.control} name="description" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description & Editing Notes</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Describe the footage and what kind of style or feel you're looking for in the edit..."
                          rows={4}
                          data-testid="input-description"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />

                  <div className="grid sm:grid-cols-2 gap-5">
                    <FormField control={form.control} name="uploaderName" render={({ field }) => (
                      <FormItem>
                        <FormLabel>Your Name</FormLabel>
                        <FormControl><Input placeholder="Alex Rivera" data-testid="input-uploader-name" {...field} /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )} />
                    <FormField control={form.control} name="uploaderEmail" render={({ field }) => (
                      <FormItem>
                        <FormLabel>Your Email</FormLabel>
                        <FormControl><Input type="email" placeholder="you@example.com" data-testid="input-uploader-email" {...field} /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )} />
                  </div>

                  <div className="pt-2 flex justify-end">
                    <Button type="submit" disabled={isUploading} className="gap-2 min-w-40" data-testid="button-submit-upload">
                      {isUploading ? "Uploading..." : <><Upload className="w-4 h-4" /> Upload Video</>}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
}
