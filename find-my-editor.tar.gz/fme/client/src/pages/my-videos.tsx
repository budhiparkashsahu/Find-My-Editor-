import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Film, Scissors, Search, Mail, ChevronRight, Loader2, Upload, Play } from "lucide-react";
import type { Video, EditedVideo } from "@shared/schema";

function VideoRow({ video }: { video: Video }) {
  const { data: edits = [] } = useQuery<EditedVideo[]>({ queryKey: [`/api/videos/${video.id}/edits`] });

  return (
    <Card className="border border-border bg-card" data-testid={`card-my-video-${video.id}`}>
      <CardContent className="p-5">
        <div className="flex items-start gap-4">
          <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-violet-100/60 to-slate-100 dark:from-violet-950/40 dark:to-slate-900 flex items-center justify-center flex-shrink-0">
            <Film className="w-7 h-7 text-primary" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap mb-1">
              <h3 className="font-semibold text-foreground text-sm">{video.title}</h3>
              <span className="text-[10px] font-medium text-primary bg-primary/10 px-2 py-0.5 rounded-full">{video.category}</span>
            </div>
            <p className="text-xs text-muted-foreground line-clamp-2 leading-relaxed mb-3">{video.description}</p>
            <div className="flex items-center gap-4 flex-wrap">
              <div className="flex items-center gap-1.5">
                <Scissors className="w-3.5 h-3.5 text-muted-foreground" />
                <span className="text-xs text-foreground font-medium">{edits.length} edit{edits.length !== 1 ? "s" : ""} submitted</span>
              </div>
              <div className="flex gap-2">
                <a href={video.fileUrl} target="_blank" rel="noopener noreferrer">
                  <Button variant="outline" size="sm" className="h-7 px-2.5 gap-1.5 text-xs" data-testid={`button-download-${video.id}`}>
                    <Play className="w-3 h-3" /> Raw
                  </Button>
                </a>
                <Link href={`/video/${video.id}`}>
                  <Button size="sm" className="h-7 px-2.5 gap-1.5 text-xs" data-testid={`button-view-${video.id}`}>
                    View Edits <ChevronRight className="w-3 h-3" />
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function MyVideosPage() {
  const [email, setEmail] = useState("");
  const [searchEmail, setSearchEmail] = useState("");

  const { data: videos = [], isLoading, error } = useQuery<Video[]>({
    queryKey: [`/api/my-videos?email=${encodeURIComponent(searchEmail)}`],
    enabled: !!searchEmail,
  });

  function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    setSearchEmail(email.trim());
  }

  return (
    <div className="min-h-screen bg-background">
      <section className="px-6 pt-16 pb-10 md:pt-20 bg-gradient-to-b from-muted/40 to-transparent">
        <div className="max-w-2xl mx-auto text-center">
          <Badge variant="secondary" className="mb-4 text-xs px-3 py-1">For Creators</Badge>
          <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-3 leading-tight" data-testid="text-my-videos-heading">
            My Uploaded Videos
          </h1>
          <p className="text-muted-foreground text-sm leading-relaxed">
            Enter the email you used when uploading to see your videos and all the edits that have been submitted.
          </p>
        </div>
      </section>

      <section className="px-6 pb-20">
        <div className="max-w-2xl mx-auto">
          {/* Email lookup */}
          <Card className="border border-border bg-card mb-8" data-testid="card-email-lookup">
            <CardContent className="p-6">
              <p className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">
                <Mail className="w-4 h-4 text-primary" /> Find your uploads
              </p>
              <form onSubmit={handleSearch} className="flex gap-3">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    type="email"
                    placeholder="Enter your upload email..."
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    className="pl-9"
                    data-testid="input-email-lookup"
                  />
                </div>
                <Button type="submit" disabled={!email} data-testid="button-search-email">
                  Search
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Results */}
          {!searchEmail ? (
            <div className="text-center py-16 text-muted-foreground">
              <div className="w-14 h-14 rounded-full bg-muted flex items-center justify-center mx-auto mb-4">
                <Mail className="w-6 h-6 text-muted-foreground" />
              </div>
              <p className="font-medium text-foreground mb-1">Enter your email above</p>
              <p className="text-sm">We'll show you all the videos you've uploaded and how many edits each has received.</p>
            </div>
          ) : isLoading ? (
            <div className="flex justify-center py-16">
              <Loader2 className="w-5 h-5 text-muted-foreground animate-spin" />
            </div>
          ) : error ? (
            <p className="text-center text-destructive text-sm py-12">Something went wrong. Please try again.</p>
          ) : videos.length === 0 ? (
            <div className="text-center py-16" data-testid="status-no-my-videos">
              <Film className="w-8 h-8 text-muted-foreground mx-auto mb-3" />
              <p className="font-semibold text-foreground mb-1">No videos found</p>
              <p className="text-sm text-muted-foreground mb-4">No uploads found for <span className="font-medium text-foreground">{searchEmail}</span></p>
              <Link href="/upload">
                <Button className="gap-2" data-testid="button-upload-first">
                  <Upload className="w-4 h-4" /> Upload Your First Video
                </Button>
              </Link>
            </div>
          ) : (
            <div>
              <p className="text-xs text-muted-foreground mb-4">{videos.length} video{videos.length !== 1 ? "s" : ""} found for {searchEmail}</p>
              <div className="space-y-4">
                {videos.map(v => <VideoRow key={v.id} video={v} />)}
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
