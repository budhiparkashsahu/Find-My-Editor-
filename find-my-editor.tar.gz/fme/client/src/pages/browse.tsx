import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, Clock, Film, Scissors, ChevronRight, Loader2 } from "lucide-react";
import { useState } from "react";
import type { Video } from "@shared/schema";

const categories = ["All", "YouTube / Vlog", "Wedding", "Short Film", "Travel", "Corporate", "Music Video", "Sports", "Documentary", "Other"];

function timeAgo(dateStr: string) {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

function VideoCard({ video }: { video: Video }) {
  return (
    <Link href={`/video/${video.id}`}>
      <Card
        className="border border-border bg-card hover:shadow-md hover:border-primary/30 transition-all cursor-pointer group"
        data-testid={`card-video-${video.id}`}
      >
        <CardContent className="p-0">
          {/* Thumbnail placeholder */}
          <div className="relative aspect-video bg-gradient-to-br from-violet-100/60 to-slate-100 dark:from-violet-950/40 dark:to-slate-900 rounded-t-lg flex items-center justify-center overflow-hidden">
            <div className="w-14 h-14 rounded-full bg-white/80 dark:bg-black/40 flex items-center justify-center shadow group-hover:scale-110 transition-transform">
              <Film className="w-6 h-6 text-primary" />
            </div>
            <div className="absolute top-2.5 right-2.5">
              <span className="bg-black/60 text-white text-[10px] px-2 py-0.5 rounded-full font-medium">RAW</span>
            </div>
            {video.status === "completed" && (
              <div className="absolute top-2.5 left-2.5">
                <span className="bg-green-500 text-white text-[10px] px-2 py-0.5 rounded-full font-medium">Edited</span>
              </div>
            )}
          </div>
          <div className="p-4">
            <div className="flex items-center gap-2 mb-1.5">
              <span className="text-[10px] font-medium text-primary bg-primary/10 px-2 py-0.5 rounded-full">{video.category}</span>
              <span className="text-xs text-muted-foreground flex items-center gap-1">
                <Clock className="w-3 h-3" /> {timeAgo(video.createdAt)}
              </span>
            </div>
            <h3 className="font-semibold text-foreground text-sm leading-snug group-hover:text-primary transition-colors mb-1 line-clamp-1">
              {video.title}
            </h3>
            <p className="text-xs text-muted-foreground line-clamp-2 leading-relaxed mb-3">
              {video.description}
            </p>
            <div className="flex items-center justify-between">
              <span className="text-xs text-muted-foreground">by {video.uploaderName}</span>
              <Button variant="ghost" size="sm" className="gap-1 text-xs h-7 px-2.5 text-primary" data-testid={`button-edit-${video.id}`}>
                <Scissors className="w-3 h-3" /> Edit this <ChevronRight className="w-3 h-3" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}

export default function BrowsePage() {
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState("All");

  const { data: videos = [], isLoading } = useQuery<Video[]>({ queryKey: ["/api/videos"] });

  const filtered = videos.filter(v => {
    const matchSearch = v.title.toLowerCase().includes(search.toLowerCase()) ||
      v.description.toLowerCase().includes(search.toLowerCase());
    const matchCat = activeCategory === "All" || v.category === activeCategory;
    return matchSearch && matchCat;
  });

  return (
    <div className="min-h-screen bg-background">
      <section className="px-6 pt-16 pb-10 md:pt-20 bg-gradient-to-b from-muted/40 to-transparent">
        <div className="max-w-2xl mx-auto text-center">
          <Badge variant="secondary" className="mb-4 text-xs px-3 py-1">For Editors</Badge>
          <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-3 leading-tight" data-testid="text-browse-heading">
            Browse raw footage
          </h1>
          <p className="text-muted-foreground text-sm leading-relaxed">
            Pick up an unedited video, apply your skills, and upload your finished cut. If the creator loves it, they'll hire you.
          </p>
        </div>
      </section>

      <section className="px-6 pb-8">
        <div className="max-w-5xl mx-auto space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search by title or description..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pl-9"
              data-testid="input-search-videos"
            />
          </div>
          <div className="flex gap-2 flex-wrap">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                data-testid={`button-filter-${cat.toLowerCase().replace(/\s+/g, "-")}`}
                className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${activeCategory === cat ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:bg-accent hover:text-accent-foreground"}`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className="px-6 pb-20">
        <div className="max-w-5xl mx-auto">
          {isLoading ? (
            <div className="flex items-center justify-center py-24">
              <Loader2 className="w-6 h-6 text-muted-foreground animate-spin" />
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-24">
              <div className="w-14 h-14 rounded-full bg-muted flex items-center justify-center mx-auto mb-4">
                <Film className="w-6 h-6 text-muted-foreground" />
              </div>
              <p className="font-semibold text-foreground mb-1">No videos found</p>
              <p className="text-sm text-muted-foreground">
                {search || activeCategory !== "All" ? "Try adjusting your filters." : "Be the first to upload raw footage!"}
              </p>
              {!search && activeCategory === "All" && (
                <Link href="/upload">
                  <Button className="mt-4 gap-2" data-testid="button-upload-empty">Upload a Video</Button>
                </Link>
              )}
            </div>
          ) : (
            <>
              <p className="text-xs text-muted-foreground mb-5">{filtered.length} video{filtered.length !== 1 ? "s" : ""} available</p>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
                {filtered.map(v => <VideoCard key={v.id} video={v} />)}
              </div>
            </>
          )}
        </div>
      </section>
    </div>
  );
}
