import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { ArrowLeft, Film, Scissors, Upload, User, UserCheck, Loader2, CheckCircle2, X, FileVideo, Play } from "lucide-react";
import type { Video, EditedVideo } from "@shared/schema";
import { useState, useRef } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

const submitEditSchema = z.object({
  editorName: z.string().min(2, "Name must be at least 2 characters"),
  editorEmail: z.string().email("Enter a valid email"),
  editorBio: z.string().min(10, "Tell us a bit about yourself (min 10 chars)"),
  description: z.string().min(10, "Describe the changes you made (min 10 chars)"),
});
type SubmitEditValues = z.infer<typeof submitEditSchema>;

const hireSchema = z.object({
  uploaderEmail: z.string().email("Enter your email"),
  message: z.string().min(10, "Please include a message (min 10 chars)"),
});
type HireValues = z.infer<typeof hireSchema>;

function HireDialog({ editedVideo, onClose }: { editedVideo: EditedVideo; onClose: () => void }) {
  const { toast } = useToast();
  const [done, setDone] = useState(false);
  const form = useForm<HireValues>({ resolver: zodResolver(hireSchema), defaultValues: { uploaderEmail: "", message: "" } });

  async function onSubmit(data: HireValues) {
    await apiRequest("POST", "/api/hire", { ...data, editedVideoId: editedVideo.id });
    setDone(true);
    toast({ title: "Hire request sent!", description: `We've notified ${editedVideo.editorName}.` });
  }

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Hire {editedVideo.editorName}</DialogTitle>
        </DialogHeader>
        {done ? (
          <div className="text-center py-6" data-testid="status-hire-sent">
            <CheckCircle2 className="w-10 h-10 text-green-500 mx-auto mb-3" />
            <p className="font-semibold text-foreground">Request sent!</p>
            <p className="text-sm text-muted-foreground mt-1">The editor will be in touch with you soon.</p>
            <Button className="mt-4" onClick={onClose} data-testid="button-close-hire">Done</Button>
          </div>
        ) : (
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-2">
              <FormField control={form.control} name="uploaderEmail" render={({ field }) => (
                <FormItem>
                  <FormLabel>Your Email (so the editor can contact you)</FormLabel>
                  <FormControl><Input type="email" placeholder="you@example.com" data-testid="input-hire-email" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="message" render={({ field }) => (
                <FormItem>
                  <FormLabel>Message to the editor</FormLabel>
                  <FormControl><Textarea placeholder="Tell them about your project, timeline, budget..." rows={4} data-testid="input-hire-message" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <div className="flex gap-3 justify-end pt-2">
                <Button variant="outline" type="button" onClick={onClose}>Cancel</Button>
                <Button type="submit" disabled={form.formState.isSubmitting} className="gap-2" data-testid="button-send-hire">
                  {form.formState.isSubmitting ? "Sending..." : <><UserCheck className="w-4 h-4" /> Send Request</>}
                </Button>
              </div>
            </form>
          </Form>
        )}
      </DialogContent>
    </Dialog>
  );
}

function SubmitEditForm({ videoId, onSuccess }: { videoId: string; onSuccess: () => void }) {
  const { toast } = useToast();
  const [editedFile, setEditedFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const qc = useQueryClient();

  const form = useForm<SubmitEditValues>({
    resolver: zodResolver(submitEditSchema),
    defaultValues: { editorName: "", editorEmail: "", editorBio: "", description: "" },
  });

  function handleFile(file: File) {
    if (!file.type.startsWith("video/")) {
      toast({ title: "Invalid file", description: "Please select a video file.", variant: "destructive" });
      return;
    }
    setEditedFile(file);
  }

  async function onSubmit(data: SubmitEditValues) {
    if (!editedFile) {
      toast({ title: "No file selected", description: "Please upload your edited video.", variant: "destructive" });
      return;
    }
    setIsUploading(true);
    try {
      const fd = new FormData();
      Object.entries(data).forEach(([k, v]) => fd.append(k, v));
      fd.append("video", editedFile);
      const res = await fetch(`/api/videos/${videoId}/edits`, { method: "POST", body: fd });
      if (!res.ok) throw new Error("Upload failed");
      await qc.invalidateQueries({ queryKey: [`/api/videos/${videoId}/edits`] });
      toast({ title: "Edit submitted!", description: "The creator can now review your work." });
      onSuccess();
    } catch {
      toast({ title: "Upload failed", description: "Something went wrong. Please try again.", variant: "destructive" });
    } finally {
      setIsUploading(false);
    }
  }

  return (
    <Card className="border border-border bg-card mt-8" data-testid="card-submit-edit">
      <CardContent className="p-6">
        <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
          <Scissors className="w-4 h-4 text-primary" /> Submit Your Edit
        </h3>
        <div
          onDragOver={e => { e.preventDefault(); setDragOver(true); }}
          onDragLeave={() => setDragOver(false)}
          onDrop={e => { e.preventDefault(); setDragOver(false); const f = e.dataTransfer.files[0]; if (f) handleFile(f); }}
          onClick={() => fileRef.current?.click()}
          className={`rounded-xl border-2 border-dashed transition-colors cursor-pointer flex flex-col items-center justify-center gap-2 py-7 px-4 text-center mb-5
            ${dragOver ? "border-primary bg-primary/5" : "border-border hover:border-primary/50 hover:bg-muted/30"}`}
          data-testid="dropzone-edited-video"
        >
          <input ref={fileRef} type="file" accept="video/*" className="hidden" onChange={e => { const f = e.target.files?.[0]; if (f) handleFile(f); }} />
          {editedFile ? (
            <div className="flex items-center gap-3">
              <FileVideo className="w-5 h-5 text-primary" />
              <div className="text-left">
                <p className="text-sm font-medium text-foreground">{editedFile.name}</p>
                <p className="text-xs text-muted-foreground">{(editedFile.size / 1024 / 1024).toFixed(1)} MB</p>
              </div>
              <button onClick={e => { e.stopPropagation(); setEditedFile(null); }} className="ml-2 text-muted-foreground hover:text-destructive">
                <X className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <>
              <Upload className="w-5 h-5 text-muted-foreground" />
              <p className="text-sm text-muted-foreground">Drop your edited video here or <span className="text-primary font-medium">browse</span></p>
            </>
          )}
        </div>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <FormField control={form.control} name="editorName" render={({ field }) => (
                <FormItem>
                  <FormLabel>Your Name</FormLabel>
                  <FormControl><Input placeholder="Jordan Lee" data-testid="input-editor-name" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="editorEmail" render={({ field }) => (
                <FormItem>
                  <FormLabel>Your Email</FormLabel>
                  <FormControl><Input type="email" placeholder="editor@example.com" data-testid="input-editor-email" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
            </div>
            <FormField control={form.control} name="editorBio" render={({ field }) => (
              <FormItem>
                <FormLabel>About You</FormLabel>
                <FormControl><Input placeholder="e.g. 3 years editing travel content, specialise in color grading" data-testid="input-editor-bio" {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )} />
            <FormField control={form.control} name="description" render={({ field }) => (
              <FormItem>
                <FormLabel>What did you change?</FormLabel>
                <FormControl><Textarea placeholder="Describe your editing choices — cuts, music, color grade, effects..." rows={3} data-testid="input-edit-description" {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )} />
            <div className="flex justify-end pt-1">
              <Button type="submit" disabled={isUploading} className="gap-2" data-testid="button-submit-edit">
                {isUploading ? <><Loader2 className="w-4 h-4 animate-spin" /> Uploading...</> : <><Upload className="w-4 h-4" /> Submit Edit</>}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}

export default function VideoDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [showSubmitForm, setShowSubmitForm] = useState(false);
  const [hireTarget, setHireTarget] = useState<EditedVideo | null>(null);

  const { data: video, isLoading: videoLoading } = useQuery<Video>({ queryKey: [`/api/videos/${id}`] });
  const { data: edits = [], isLoading: editsLoading } = useQuery<EditedVideo[]>({ queryKey: [`/api/videos/${id}/edits`] });

  if (videoLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-6 h-6 text-muted-foreground animate-spin" />
      </div>
    );
  }

  if (!video) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="font-semibold text-foreground">Video not found</p>
          <Link href="/browse"><Button className="mt-4">Back to Browse</Button></Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto px-6 py-10">
        {/* Back */}
        <Link href="/browse">
          <Button variant="ghost" size="sm" className="gap-2 mb-6 px-0 text-muted-foreground hover:text-foreground" data-testid="button-back">
            <ArrowLeft className="w-4 h-4" /> Back to Browse
          </Button>
        </Link>

        {/* Original Video Card */}
        <Card className="border border-border bg-card mb-8" data-testid="card-original-video">
          <CardContent className="p-6 md:p-8">
            <div className="flex flex-col md:flex-row gap-6">
              {/* Thumbnail */}
              <div className="aspect-video md:w-64 flex-shrink-0 bg-gradient-to-br from-violet-100/60 to-slate-100 dark:from-violet-950/40 dark:to-slate-900 rounded-xl flex items-center justify-center">
                <div className="flex flex-col items-center gap-2">
                  <div className="w-12 h-12 rounded-full bg-white/80 dark:bg-black/40 flex items-center justify-center shadow">
                    <Film className="w-6 h-6 text-primary" />
                  </div>
                  <span className="text-xs text-muted-foreground font-medium">Raw Footage</span>
                </div>
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex flex-wrap items-center gap-2 mb-3">
                  <Badge variant="secondary" className="text-xs">{video.category}</Badge>
                  <Badge variant="outline" className="text-xs text-amber-600 border-amber-300 dark:border-amber-700 dark:text-amber-400">RAW</Badge>
                </div>
                <h1 className="text-xl md:text-2xl font-bold text-foreground mb-2 leading-tight" data-testid="text-video-title">{video.title}</h1>
                <p className="text-sm text-muted-foreground leading-relaxed mb-4">{video.description}</p>
                <div className="flex items-center gap-2 mb-5">
                  <div className="w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center">
                    <User className="w-3.5 h-3.5 text-primary" />
                  </div>
                  <span className="text-sm text-foreground font-medium">{video.uploaderName}</span>
                </div>

                {/* Download / Play */}
                <div className="flex gap-3 flex-wrap">
                  <a href={video.fileUrl} target="_blank" rel="noopener noreferrer">
                    <Button variant="outline" size="sm" className="gap-2" data-testid="button-play-original">
                      <Play className="w-3.5 h-3.5" /> Play / Download Raw
                    </Button>
                  </a>
                  <Button
                    size="sm"
                    className="gap-2"
                    onClick={() => setShowSubmitForm(true)}
                    data-testid="button-open-submit-edit"
                  >
                    <Scissors className="w-3.5 h-3.5" /> Submit My Edit
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Edited Versions */}
        <div>
          <div className="flex items-center justify-between mb-5">
            <h2 className="text-lg font-bold text-foreground">
              Edited Versions
              {edits.length > 0 && (
                <span className="ml-2 text-sm font-normal text-muted-foreground">({edits.length})</span>
              )}
            </h2>
            {!showSubmitForm && (
              <Button size="sm" variant="outline" className="gap-2" onClick={() => setShowSubmitForm(true)} data-testid="button-add-edit">
                <Upload className="w-3.5 h-3.5" /> Add Your Edit
              </Button>
            )}
          </div>

          {editsLoading ? (
            <div className="flex justify-center py-12"><Loader2 className="w-5 h-5 text-muted-foreground animate-spin" /></div>
          ) : edits.length === 0 && !showSubmitForm ? (
            <div className="text-center py-14 border border-dashed border-border rounded-xl" data-testid="status-no-edits">
              <Scissors className="w-8 h-8 text-muted-foreground mx-auto mb-3" />
              <p className="font-semibold text-foreground mb-1">No edits yet</p>
              <p className="text-sm text-muted-foreground mb-4">Be the first editor to take on this project!</p>
              <Button className="gap-2" onClick={() => setShowSubmitForm(true)} data-testid="button-be-first-editor">
                <Scissors className="w-4 h-4" /> Submit an Edit
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {edits.map(edit => (
                <Card key={edit.id} className="border border-border bg-card" data-testid={`card-edit-${edit.id}`}>
                  <CardContent className="p-5">
                    <div className="flex flex-col md:flex-row gap-5">
                      <div className="aspect-video md:w-44 flex-shrink-0 bg-gradient-to-br from-green-50 to-teal-50 dark:from-green-950/30 dark:to-teal-950/30 rounded-lg flex items-center justify-center">
                        <a href={edit.fileUrl} target="_blank" rel="noopener noreferrer" className="flex flex-col items-center gap-1.5 group">
                          <div className="w-10 h-10 rounded-full bg-white/80 dark:bg-black/40 flex items-center justify-center shadow group-hover:scale-110 transition-transform">
                            <Play className="w-4 h-4 text-green-600 dark:text-green-400" />
                          </div>
                          <span className="text-[10px] text-muted-foreground">Play Edit</span>
                        </a>
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-2">
                          <div className="w-7 h-7 rounded-full bg-violet-100 dark:bg-violet-900/30 flex items-center justify-center">
                            <Scissors className="w-3.5 h-3.5 text-primary" />
                          </div>
                          <div>
                            <p className="text-sm font-semibold text-foreground">{edit.editorName}</p>
                            <p className="text-xs text-muted-foreground">{edit.editorBio}</p>
                          </div>
                        </div>
                        <p className="text-sm text-muted-foreground leading-relaxed mb-4">{edit.description}</p>
                        <Button
                          size="sm"
                          className="gap-2"
                          onClick={() => setHireTarget(edit)}
                          data-testid={`button-hire-${edit.id}`}
                        >
                          <UserCheck className="w-3.5 h-3.5" /> Hire This Editor
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          {showSubmitForm && (
            <SubmitEditForm videoId={id!} onSuccess={() => setShowSubmitForm(false)} />
          )}
        </div>
      </div>

      {/* Hire Dialog */}
      {hireTarget && <HireDialog editedVideo={hireTarget} onClose={() => setHireTarget(null)} />}
    </div>
  );
}
