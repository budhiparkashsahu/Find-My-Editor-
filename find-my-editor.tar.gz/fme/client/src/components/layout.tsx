import { Link, useLocation } from "wouter";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Home, Upload, Search, Video, Menu, X, Scissors } from "lucide-react";
import { cn } from "@/lib/utils";

const navItems = [
  { href: "/", label: "Home", icon: Home },
  { href: "/upload", label: "Upload Video", icon: Upload },
  { href: "/browse", label: "Browse & Edit", icon: Search },
  { href: "/my-videos", label: "My Uploads", icon: Video },
];

export default function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background flex">
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex w-62 flex-col fixed inset-y-0 left-0 z-40 bg-sidebar border-r border-sidebar-border" style={{ width: 248 }}>
        <div className="flex items-center gap-2.5 px-5 h-16 border-b border-sidebar-border">
          <div className="w-8 h-8 rounded-xl bg-primary flex items-center justify-center flex-shrink-0 shadow-sm">
            <Scissors className="w-4 h-4 text-primary-foreground" />
          </div>
          <div>
            <p className="font-bold text-sidebar-foreground text-sm leading-tight tracking-tight">Find My Editor</p>
            <p className="text-[10px] text-muted-foreground leading-tight">Video Editing Marketplace</p>
          </div>
        </div>

        <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
          {navItems.map(({ href, label, icon: Icon }) => {
            const active = location === href;
            return (
              <Link key={href} href={href}>
                <span
                  data-testid={`nav-link-${label.toLowerCase().replace(/\s+/g, "-")}`}
                  className={cn(
                    "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors cursor-pointer",
                    active
                      ? "bg-primary text-primary-foreground shadow-sm"
                      : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                  )}
                >
                  <Icon className="w-4 h-4 flex-shrink-0" />
                  {label}
                </span>
              </Link>
            );
          })}
        </nav>

        <div className="px-5 py-4 border-t border-sidebar-border">
          <p className="text-xs text-muted-foreground">© 2026 Find My Editor</p>
        </div>
      </aside>

      {/* Mobile Header */}
      <header className="md:hidden fixed top-0 left-0 right-0 z-40 h-14 bg-sidebar border-b border-sidebar-border flex items-center justify-between px-4">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-primary flex items-center justify-center">
            <Scissors className="w-3.5 h-3.5 text-primary-foreground" />
          </div>
          <span className="font-bold text-sidebar-foreground text-sm">Find My Editor</span>
        </div>
        <Button variant="ghost" size="icon" data-testid="button-mobile-menu" onClick={() => setMobileOpen(!mobileOpen)} className="h-8 w-8">
          {mobileOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
        </Button>
      </header>

      {/* Mobile Drawer */}
      {mobileOpen && (
        <div className="md:hidden fixed inset-0 z-30 bg-black/40" onClick={() => setMobileOpen(false)}>
          <aside className="absolute left-0 top-14 bottom-0 w-60 bg-sidebar border-r border-sidebar-border p-3 space-y-0.5" onClick={e => e.stopPropagation()}>
            {navItems.map(({ href, label, icon: Icon }) => {
              const active = location === href;
              return (
                <Link key={href} href={href}>
                  <span
                    onClick={() => setMobileOpen(false)}
                    className={cn(
                      "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors cursor-pointer",
                      active ? "bg-primary text-primary-foreground" : "text-sidebar-foreground hover:bg-sidebar-accent"
                    )}
                  >
                    <Icon className="w-4 h-4" />
                    {label}
                  </span>
                </Link>
              );
            })}
          </aside>
        </div>
      )}

      {/* Main Content */}
      <main className="flex-1 md:ml-[248px] pt-14 md:pt-0 min-h-screen">
        {children}
      </main>
    </div>
  );
}
