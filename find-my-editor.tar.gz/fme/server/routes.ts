import type { Express } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import path from "path";
import { randomUUID } from "crypto";
import { storage } from "./storage";
import { insertVideoSchema, insertEditedVideoSchema, insertHireRequestSchema } from "@shared/schema";

const upload = multer({
  storage: multer.diskStorage({
    destination: "public/uploads/",
    filename: (_req, file, cb) => {
      const ext = path.extname(file.originalname);
      cb(null, `${randomUUID()}${ext}`);
    },
  }),
  limits: { fileSize: 500 * 1024 * 1024 }, // 500 MB
  fileFilter: (_req, file, cb) => {
    const allowed = ["video/mp4", "video/webm", "video/quicktime", "video/x-msvideo", "video/mpeg"];
    cb(null, allowed.includes(file.mimetype));
  },
});

export async function registerRoutes(httpServer: Server, app: Express): Promise<Server> {

  // --- Videos ---
  app.get("/api/videos", async (_req, res) => {
    const videos = await storage.getAllVideos();
    res.json(videos);
  });

  app.get("/api/videos/:id", async (req, res) => {
    const video = await storage.getVideo(req.params.id);
    if (!video) return res.status(404).json({ message: "Video not found" });
    res.json(video);
  });

  app.get("/api/my-videos", async (req, res) => {
    const email = req.query.email as string;
    if (!email) return res.status(400).json({ message: "Email required" });
    const videos = await storage.getVideosByEmail(email);
    res.json(videos);
  });

  app.post("/api/videos", upload.single("video"), async (req, res) => {
    try {
      const parsed = insertVideoSchema.safeParse(req.body);
      if (!parsed.success) return res.status(400).json({ message: "Invalid data", errors: parsed.error.errors });
      if (!req.file) return res.status(400).json({ message: "Video file is required" });

      const video = await storage.createVideo({
        ...parsed.data,
        fileName: req.file.originalname,
        fileUrl: `/uploads/${req.file.filename}`,
      });
      res.status(201).json(video);
    } catch (e) {
      res.status(500).json({ message: "Upload failed" });
    }
  });

  // --- Edited Videos ---
  app.get("/api/videos/:id/edits", async (req, res) => {
    const edits = await storage.getEditedVideosByOriginal(req.params.id);
    res.json(edits);
  });

  app.post("/api/videos/:id/edits", upload.single("video"), async (req, res) => {
    try {
      const parsed = insertEditedVideoSchema.safeParse({
        ...req.body,
        originalVideoId: req.params.id,
      });
      if (!parsed.success) return res.status(400).json({ message: "Invalid data", errors: parsed.error.errors });
      if (!req.file) return res.status(400).json({ message: "Edited video file is required" });

      const original = await storage.getVideo(req.params.id);
      if (!original) return res.status(404).json({ message: "Original video not found" });

      const edited = await storage.createEditedVideo({
        ...parsed.data,
        fileName: req.file.originalname,
        fileUrl: `/uploads/${req.file.filename}`,
      });
      res.status(201).json(edited);
    } catch (e) {
      res.status(500).json({ message: "Upload failed" });
    }
  });

  // --- Hire Requests ---
  app.post("/api/hire", async (req, res) => {
    const parsed = insertHireRequestSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ message: "Invalid data" });
    const hire = await storage.createHireRequest(parsed.data);
    res.status(201).json(hire);
  });

  return httpServer;
}
