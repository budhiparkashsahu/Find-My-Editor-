import { randomUUID } from "crypto";
import {
  type User,
  type InsertUser,
  type Video,
  type InsertVideo,
  type EditedVideo,
  type InsertEditedVideo,
  type HireRequest,
  type InsertHireRequest,
} from "@shared/schema";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  getAllVideos(): Promise<Video[]>;
  getVideo(id: string): Promise<Video | undefined>;
  getVideosByEmail(email: string): Promise<Video[]>;
  createVideo(video: InsertVideo): Promise<Video>;

  getEditedVideosByOriginal(originalVideoId: string): Promise<EditedVideo[]>;
  getEditedVideo(id: string): Promise<EditedVideo | undefined>;
  createEditedVideo(ev: InsertEditedVideo): Promise<EditedVideo>;

  createHireRequest(req: InsertHireRequest): Promise<HireRequest>;
  getHireRequestsByEditedVideo(editedVideoId: string): Promise<HireRequest[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private videos: Map<string, Video> = new Map();
  private editedVideos: Map<string, EditedVideo> = new Map();
  private hireRequests: Map<string, HireRequest> = new Map();

  async getUser(id: string) { return this.users.get(id); }
  async getUserByUsername(username: string) {
    return Array.from(this.users.values()).find(u => u.username === username);
  }
  async createUser(insertUser: InsertUser): Promise<User> {
    const user: User = { ...insertUser, id: randomUUID() };
    this.users.set(user.id, user);
    return user;
  }

  async getAllVideos(): Promise<Video[]> {
    return Array.from(this.videos.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }
  async getVideo(id: string) { return this.videos.get(id); }
  async getVideosByEmail(email: string): Promise<Video[]> {
    return Array.from(this.videos.values()).filter(v => v.uploaderEmail === email);
  }
  async createVideo(v: InsertVideo): Promise<Video> {
    const video: Video = { ...v, id: randomUUID(), status: "open", createdAt: new Date().toISOString() };
    this.videos.set(video.id, video);
    return video;
  }

  async getEditedVideosByOriginal(originalVideoId: string): Promise<EditedVideo[]> {
    return Array.from(this.editedVideos.values()).filter(ev => ev.originalVideoId === originalVideoId);
  }
  async getEditedVideo(id: string) { return this.editedVideos.get(id); }
  async createEditedVideo(ev: InsertEditedVideo): Promise<EditedVideo> {
    const edited: EditedVideo = { ...ev, id: randomUUID(), createdAt: new Date().toISOString() };
    this.editedVideos.set(edited.id, edited);
    return edited;
  }

  async createHireRequest(req: InsertHireRequest): Promise<HireRequest> {
    const hire: HireRequest = { ...req, id: randomUUID(), createdAt: new Date().toISOString() };
    this.hireRequests.set(hire.id, hire);
    return hire;
  }
  async getHireRequestsByEditedVideo(editedVideoId: string): Promise<HireRequest[]> {
    return Array.from(this.hireRequests.values()).filter(h => h.editedVideoId === editedVideoId);
  }
}

export const storage = new MemStorage();
