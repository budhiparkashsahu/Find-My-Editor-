import { sql } from "drizzle-orm";
import { pgTable, text, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type VideoStatus = "open" | "completed";

export type Video = {
  id: string;
  title: string;
  description: string;
  category: string;
  uploaderName: string;
  uploaderEmail: string;
  fileName: string;
  fileUrl: string;
  status: VideoStatus;
  createdAt: string;
};

export type InsertVideo = Omit<Video, "id" | "createdAt" | "status">;

export type EditedVideo = {
  id: string;
  originalVideoId: string;
  editorName: string;
  editorEmail: string;
  editorBio: string;
  fileName: string;
  fileUrl: string;
  description: string;
  createdAt: string;
};

export type InsertEditedVideo = Omit<EditedVideo, "id" | "createdAt">;

export type HireRequest = {
  id: string;
  editedVideoId: string;
  uploaderEmail: string;
  message: string;
  createdAt: string;
};

export type InsertHireRequest = Omit<HireRequest, "id" | "createdAt">;

export const insertVideoSchema = z.object({
  title: z.string().min(3),
  description: z.string().min(10),
  category: z.string().min(1),
  uploaderName: z.string().min(2),
  uploaderEmail: z.string().email(),
});

export const insertEditedVideoSchema = z.object({
  originalVideoId: z.string(),
  editorName: z.string().min(2),
  editorEmail: z.string().email(),
  editorBio: z.string().min(10),
  description: z.string().min(10),
});

export const insertHireRequestSchema = z.object({
  editedVideoId: z.string(),
  uploaderEmail: z.string().email(),
  message: z.string().min(10),
});
